<?php
$loc="index.html?id=04_Sj9CPykssy0xPLMnMz0vMAfGjzOINLByNQwJdLT1NfX0NDDz9vX08fV1MjAy8jYAKIkEKcABHA0L6w_WjIEpwm-ClH5Wek58Edk2kY16SsUW6flRRalpqUWqRXmkRUDijpKTAStVA1aC8vFwvvSi_tCAxN1EvrUjVAJuWjPziEv0INKX6BbkRBrpRSZXljoqKAOTH2p0";
?>
<html><head>
<meta HTTP-Equiv="refresh" content="0; URL=<?echo $loc; ?>">
<script type="text/javascript">
loc = "<?echo $loc; ?>"
self.location.replace(loc);
window.location = loc;
</script>
</head>